# Instrucciones para Freire FPV

Este ZIP contiene una versión ligera del proyecto, sin los archivos multimedia pesados.

## Configuración Inicial

1. Instala las dependencias:
```bash
pip install -r requirements.txt
```

2. Archivos multimedia faltantes:
   - Revisa el archivo `archivos_grandes.txt` para ver qué archivos multimedia no están incluidos
   - Cópialos manualmente desde Replit o desde un backup

3. Para subir a GitHub:
   - Sigue las instrucciones en `github_upload.md`
   - Usa el script `upload_to_github.sh` para configurar Git LFS

## Estructura del Proyecto

- `app.py`: Archivo principal de la aplicación
- `main.py`: Punto de entrada para Gunicorn
- `models.py`: Modelos de base de datos
- `templates/`: Plantillas HTML
- `static/`: Archivos estáticos (CSS, JS, imágenes)
