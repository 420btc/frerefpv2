# GIFs de precarga\nArchivos grandes excluidos del ZIP. Añádelos manualmente.
